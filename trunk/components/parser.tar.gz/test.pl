#!/usr/bin/perl
# create an XML-compliant string

print "Hello perl";
